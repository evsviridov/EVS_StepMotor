#include "EVS_filter.h"

int filterMedian(int *v, int num = 3)
{
    int middle;
    int a, b, c;
    a = v[0];
    b = v[1];
    c = v[2];
    if ((a <= b) && (a <= c))
    {
        middle = (b <= c) ? b : c;
    }
    else
    {
        if ((b <= a) && (b <= c))
        {
            middle = (a <= c) ? a : c;
        }
        else
        {
            middle = (a <= b) ? a : b;
        }
    }
    return middle;
}

int filterMean(int *v, int num)
{
    int sum = 0;
    for (int i = 0; i < num; ++i)
        sum += v[i];
    return sum / num;
}
