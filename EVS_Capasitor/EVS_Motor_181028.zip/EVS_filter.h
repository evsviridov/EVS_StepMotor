#pragma once

#ifndef __EVS_FILTER_H
#define __EVS_FILTER_H

int filterMedian(int *v, int num = 3);
int filterMean(int *v, int num);

#endif __EVS_FILTER_H
