#pragma once

#ifndef __EVS_STREAM_H
#define __EVS_STREAM_H


#endif __EVS_STREAM_H