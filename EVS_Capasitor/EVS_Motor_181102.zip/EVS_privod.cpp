#include "EVS_privod.h"

int EVS_privod::init(void)
{
    int err;
    if (_privod_functions._beforeInitFunc != NULL)
    {
        err = _privod_functions._beforeInitFunc(this);
        if (err)
            return err;
    }
    EVS_motor::init();
}

void EVS_privod::setEna(bool value)
{
    if (_privod_functions._beforeENAFunc != NULL)
    {
        int err = _privod_functions._beforeENAFunc(this);
        if (err)
            return err;
    }
    EVS_motor::setEna(value);
}

void EVS_privod::setDir(bool value)
{
    if (_privod_functions._beforeDIRFunc != NULL)
    {
        int err = _privod_functions._beforeDIRFunc(this);
        if (err)
            return err;
    }
    EVS_motor::setDir(value);
}

int EVS_privod::pul(void)
{
    if (_privod_functions._beforePULFunc != NULL)
    {
        int err = _privod_functions._beforePULFunc(this);
        if (err)
            return err;
    }
    EVS_motor::pul();
    if (_privod_functions._afterPULFunc != NULL)
    {
        int err = _privod_functions._afterPULFunc(this);
        if (err)
            return err;
    }
    return 0;
}

bool EVS_privod::isOnTarget(void)
{
    float multiple_diff;
    float abs_diff, abs_diff_prev;
    _position_error._diff = getCurrentPosition() - _privod_position._target;
    abs_diff = fabs(_position_error._diff);
    abs_diff_prev = fabs(_position_error._diff_prev);

    multiple_diff = _position_error._diff * _position_error._diff_prev;
    if (_privod_status._isOnTarget)
    {
        if ((abs_diff > _position_error._max_error) && (abs_diff_prev > _position_error._max_error))
        {
            _privod_status._isOnTarget = 0;
        }
    }
    else
    {
        if ((abs_diff <= _position_error._min_error) && (abs_diff_prev <= _position_error._min_error) && multiple_diff <= 0)
        {
            _privod_status._isOnTarget = 1;
        }
    }
    _position_error._diff_prev = _position_error._diff;
    return _privod_status._isOnTarget;
}

float EVS_privod::getCurrentPosition(void)
{
    if (_privod_functions._measureCurrentPositionFunc != NULL)
    {
        int err = _privod_functions._measureCurrentPositionFunc(this);
        if (err)
            return err;
    }
    return _privod_position._current;
}

void EVS_privod::setCurrentPosition(float position)
{
    _privod_position._current = position;
}

void EVS_privod::setTargetPosition(float targetPosition, float minPosition = 0, float maxPosition = 100.0)
{
    targetPosition = fmax(targetPosition, minPosition);
    targetPosition = fmin(targetPosition, maxPosition);
    _privod_position._target = targetPosition;

    _position_error._diff_prev = getCurrentPosition() - _privod_position._target;
    _position_error._diff = _position_error._diff_prev;
    _privod_status._isOnTarget = FALSE;
    setDirectionToTarget();
}

float EVS_privod::getTargetPosition(void)
{
    return _privod_position._target;
}

float EVS_privod::getPositionError(void)
{
    return _position_error._diff;
}

void EVS_privod::setPositionErrorRange(float min_error, float max_error)
{
    _position_error._min_error = min_error;
    _position_error._max_error = max_error;
}

void EVS_privod::setDirectionToTarget(void)
{
    if (IS_LESS(_privod_position._current, _privod_position._target + _position_error._min_error, 0.0))
    {
        if (!getDir())
            setDir(TRUE);
        return;
    }
    if (IS_MORE(_privod_position._current, _privod_position._target - _position_error._min_error, 0.0))
    {
        if (getDir())
            setDir(FALSE);
        return;
    }
}

void EVS_privod::setBeforeInitFunc(EVS_privod_function *func)
{
    _privod_functions._beforeInitFunc = func;
}

void EVS_privod::setBeforePulFunc(EVS_privod_function *func)
{
    _privod_functions._beforePULFunc = func;
}

void EVS_privod::setAfterPulFunc(EVS_privod_function *func)
{
    _privod_functions._afterPULFunc = func;
}

void EVS_privod::setBeforeEnaFunc(EVS_privod_function *func)
{
    _privod_functions._beforeENAFunc = func;
}

void EVS_privod::setMeasurePositionFunc(EVS_privod_function *func)
{
    _privod_functions._measureCurrentPositionFunc = func;
}
