#include "EVS_voltmeter.h"

int doVoltmeter(int pin, float *fValue = NULL, int mSec = 20)
{
    unsigned long starttime, endtime, delayUs;

    long lValue = 0;
    long n = 0;

    delayUs = (unsigned long)mSec * 1000UL;
    starttime = micros();
    do
    {
        lValue += analogRead(pin);
        ++n;
    } while ((micros() - starttime) <= delayUs);
    if (fValue)
    {
        *fValue = ((float)lValue) / ((float)n);
        *fValue /=  ADC_RANGE;
    }
    return (int)(lValue / n);
}

