#ifndef __EVS_PRIVOD_H
#define __EVS_PRIVOD_H

#include "EVS_motor.h"

#define ERR_POSITION_MIN (0.03)
#define ERR_POSITION_MAX (0.08)

#define IS_LESS(a, b, eps) ((a) < ((b) - (eps)))
#define IS_MORE(a, b, eps) ((a) > ((b) + (eps)))
#define IS_EQUAL(a, b, eps) (fabs((a) - (b)) < (eps))

struct EVS_privod_status
{
    bool _isIdle : 1;
    bool _isMoving : 1;
    bool _isAutoMove : 1;
    bool _isOnTarget : 1;
    bool _isInsideRange : 1;
    bool _isLoSide : 1;
    bool _isHiSide : 1;
};

typedef int EVS_privod_function(class EVS_privod *privod);
struct EVS_privod_functions
{
    EVS_privod_function *_beforeInitFunc = NULL;
    EVS_privod_function *_beforePULFunc = NULL;
    EVS_privod_function *_afterPULFunc = NULL;
    EVS_privod_function *_beforeENAFunc = NULL;
    EVS_privod_function *_beforeDIRFunc = NULL;
    EVS_privod_function *_measureCurrentPositionFunc = NULL;
};

struct EVS_privod_position
{
    float _current;
    float _target;
};

struct EVS_privod_position_error
{
    float _diff, _diff_prev;
    long _time, _time_prev;
    float _min_error = ERR_POSITION_MIN;
    float _max_error = ERR_POSITION_MAX;

};

class EVS_privod : public EVS_motor
{
  private:
    EVS_privod_functions _privod_functions;
    EVS_privod_status _privod_status;
    EVS_privod_position _privod_position;
    EVS_privod_position_error _position_error;

  public:
    int init(void);

    void setEna(bool value);

    void setDir(bool value);

    int pul(void);

    bool isOnTarget(void);

    float getCurrentPosition(void);

    void setCurrentPosition(float position);

    void setTargetPosition(float targetPosition, float minPosition = 0, float maxPosition = 100.0);

    float getTargetPosition(void);

    void setDirectionToTarget(void);

    float getPositionError(void);

    void setPositionErrorRange(float min_error = ERR_POSITION_MIN, float max_error = ERR_POSITION_MAX);

    void setBeforeInitFunc(EVS_privod_function *func);
    void setBeforePulFunc(EVS_privod_function *func);
    void setAfterPulFunc(EVS_privod_function *func);
    void setBeforeEnaFunc(EVS_privod_function *func);
    void setMeasurePositionFunc(EVS_privod_function *func);
};

#endif __EVS_PRIVOD_H