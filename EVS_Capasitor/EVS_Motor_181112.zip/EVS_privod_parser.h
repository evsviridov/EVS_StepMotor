#ifndef __EVS_PRIVOD_PARSER_H
#define __EVS_PRIVOD_PARSER_H

#include <Arduino.h>

class EVS_parser 
{
    private:
        HardwareSerial *_inStream, *_outStream;
    protected:
    public:
        EVS_parser();
        int scanInputStream()
        {
            int len=_inStream->available();
            if(len)
            {
                
            }
        }

};

#endif __EVS_PRIVOD_PARSER_H
